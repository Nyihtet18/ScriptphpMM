////// SLOVE ALL Problem ///
    @@@@@@@@@@@@@@@@@@@@



@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Stet 1
Install Common in termux with step by step in video
Video Link: https://youtu.be/CwZFUZFgTgs?si=3lAP-dn0Ed49gjiP
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@





@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Step 2 
Install Httpcanary In Android Version 7 to 13
Video link: https://youtu.be/i8vvDE7C1pg?si=D7GGV8Wrpl1JKJFK
App Link: www.scriptphp-mm.nl/AppForTermux
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@





@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Step3 ( Run Script Everything ) 
Script 
www.scriptphp-mm.nl/ 
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@




@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if you can't slove problem ,come community telegram 
https://t.me/etcformatrader
https://t.me/Termuxcryptomyanmar
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                         Writing 
                      Scriphptphp-MM 